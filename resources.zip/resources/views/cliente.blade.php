@extends('plantilla')

@section('contenido')

    <h2>Cliente</h2>
    Nombre <input type="text"><br>
    Edad <input type="number"><br>
    Correo <input type="email"><br>

    @endsection
