@extends('plantilla')

@section('contenido')

<h2>Inicio</h2>

<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque, rem laboriosam. Harum error repellat, tempore nostrum eos recusandae, assumenda officia, repudiandae vel cum ipsa id nulla quae temporibus facere distinctio.</p>

@endsection